﻿Imports MySql.Data.MySqlClient

Public Class Form_CRUD_Team



    Sub FormRefresh()
        Dim team_table As DataTable


        team_table = getAllTeamRecord()

        Me.DataGridView1.DataSource = team_table


    End Sub
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Form1.Show()
        Me.Close()
    End Sub

    Private Sub SEARCH_BTTN_Click(sender As Object, e As EventArgs) Handles SEARCH_BTTN.Click


        Dim TEAMID As String = TEAMID_TB.Text
        If String.IsNullOrEmpty(TEAMID) Then
            MessageBox.Show("Please enter a TeamID.")
            Return
        End If

        Try
            Module1.connectDB()

            Dim sql As String = "SELECT * FROM teams WHERE TeamID = @TeamID"

            Using myCmd As New MySqlCommand(sql, myConn)
                myCmd.Parameters.AddWithValue("@TeamID", TEAMID)

                Using reader As MySqlDataReader = myCmd.ExecuteReader()
                    If reader.Read() Then


                        TEAMNAME_TB.Text = reader("TeamName").ToString()
                        COUNTRY_CB.Text = reader("Country").ToString()
                        HEADCOACH_TB.Text = reader("HeadCoach").ToString()
                        ESTABLISHEDYEAR_CB.Text = reader("EstablishedYear").ToString()
                        CHAMPIONSHIP_NUD.Text = reader("Championships").ToString()
                        GENERALMANAGER_TB.Text = reader("GeneralManager").ToString()


                        MessageBox.Show("Team found.")
                    Else
                        MessageBox.Show("Team not found.")
                    End If
                End Using
            End Using
        Catch ex As Exception
            MessageBox.Show("An error occurred: " & ex.Message)
        End Try

    End Sub

    Private Sub NEW_BTTN_Click(sender As Object, e As EventArgs) Handles NEW_BTTN.Click
        TEAMID_TB.Clear()
        TEAMNAME_TB.Clear()
        GENERALMANAGER_TB.Clear()
        HEADCOACH_TB.Clear()
        COUNTRY_CB.SelectedIndex = -1
        ESTABLISHEDYEAR_CB.SelectedIndex = -1
        CHAMPIONSHIP_NUD.Value = 0

    End Sub

    Private Sub CREATE_BTTN_Click(sender As Object, e As EventArgs) Handles CREATE_BTTN.Click
        addTeamInfo()

        Dim team_table = getAllTeamRecord()

        Me.DataGridView1.DataSource = team_table
    End Sub

    Private Sub UPDATE_BTTN_Click(sender As Object, e As EventArgs) Handles UPDATE_BTTN.Click
        If TEAMID_TB.Text <> "" Then
            updateTeamRecord()
            If remark = "Successful" Then
                MsgBox("Team Record Seuccessfully Updated")
                FormRefresh()

            End If
        Else
            MsgBox("Please Search Team Record to the updated")
        End If
    End Sub

    Private Sub Form_CRUD_Team_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub

    Private Sub DELETE_BTTN_Click(sender As Object, e As EventArgs) Handles DELETE_BTTN.Click
        deleteteamRecord()


        FormRefresh()

    End Sub

    Private Sub DataGridView1_CellContentClick(sender As Object, e As DataGridViewCellEventArgs) Handles DataGridView1.CellContentClick

        If e.ColumnIndex >= 0 AndAlso e.RowIndex >= 0 Then
            TEAMID_TB.Text = DataGridView1.Rows(e.RowIndex).Cells(0).Value
            TEAMNAME_TB.Text = DataGridView1.Rows(e.RowIndex).Cells(1).Value
            COUNTRY_CB.Text = DataGridView1.Rows(e.RowIndex).Cells(2).Value
            HEADCOACH_TB.Text = DataGridView1.Rows(e.RowIndex).Cells(3).Value
            ESTABLISHEDYEAR_CB.Text = DataGridView1.Rows(e.RowIndex).Cells(4).Value
            CHAMPIONSHIP_NUD.Value = DataGridView1.Rows(e.RowIndex).Cells(5).Value
            GENERALMANAGER_TB.Text = DataGridView1.Rows(e.RowIndex).Cells(6).Value





        End If
    End Sub
End Class