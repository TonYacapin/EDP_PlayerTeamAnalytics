﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form_CRUD_Team
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.DataGridView1 = New System.Windows.Forms.DataGridView()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.DELETE_BTTN = New System.Windows.Forms.Button()
        Me.UPDATE_BTTN = New System.Windows.Forms.Button()
        Me.CREATE_BTTN = New System.Windows.Forms.Button()
        Me.NEW_BTTN = New System.Windows.Forms.Button()
        Me.TEAMID_TB = New System.Windows.Forms.TextBox()
        Me.TEAMNAME_TB = New System.Windows.Forms.TextBox()
        Me.HEADCOACH_TB = New System.Windows.Forms.TextBox()
        Me.GENERALMANAGER_TB = New System.Windows.Forms.TextBox()
        Me.COUNTRY_CB = New System.Windows.Forms.ComboBox()
        Me.ESTABLISHEDYEAR_CB = New System.Windows.Forms.ComboBox()
        Me.CHAMPIONSHIP_NUD = New System.Windows.Forms.NumericUpDown()
        Me.SEARCH_BTTN = New System.Windows.Forms.Button()
        Me.Label8 = New System.Windows.Forms.Label()
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.CHAMPIONSHIP_NUD, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'Button1
        '
        Me.Button1.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.89565!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button1.Location = New System.Drawing.Point(441, 13)
        Me.Button1.Margin = New System.Windows.Forms.Padding(4)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(230, 39)
        Me.Button1.TabIndex = 3
        Me.Button1.Text = "MAIN MENU"
        Me.Button1.UseVisualStyleBackColor = True
        '
        'DataGridView1
        '
        Me.DataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DataGridView1.Location = New System.Drawing.Point(13, 60)
        Me.DataGridView1.Margin = New System.Windows.Forms.Padding(4)
        Me.DataGridView1.Name = "DataGridView1"
        Me.DataGridView1.RowHeadersWidth = 49
        Me.DataGridView1.Size = New System.Drawing.Size(653, 219)
        Me.DataGridView1.TabIndex = 4
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(34, 303)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(56, 16)
        Me.Label1.TabIndex = 5
        Me.Label1.Text = "TeamID"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(21, 333)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(83, 16)
        Me.Label2.TabIndex = 6
        Me.Label2.Text = "TeamName "
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(36, 364)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(52, 16)
        Me.Label3.TabIndex = 7
        Me.Label3.Text = "Country"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(336, 299)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(80, 16)
        Me.Label4.TabIndex = 8
        Me.Label4.Text = "HeadCoach"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(9, 399)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(107, 16)
        Me.Label5.TabIndex = 9
        Me.Label5.Text = "EstablishedYear"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(12, 430)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(100, 16)
        Me.Label6.TabIndex = 10
        Me.Label6.Text = "Championships"
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(336, 329)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(109, 16)
        Me.Label7.TabIndex = 11
        Me.Label7.Text = "GeneralManager"
        '
        'DELETE_BTTN
        '
        Me.DELETE_BTTN.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.89565!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.DELETE_BTTN.Location = New System.Drawing.Point(227, 538)
        Me.DELETE_BTTN.Margin = New System.Windows.Forms.Padding(4)
        Me.DELETE_BTTN.Name = "DELETE_BTTN"
        Me.DELETE_BTTN.Size = New System.Drawing.Size(230, 30)
        Me.DELETE_BTTN.TabIndex = 36
        Me.DELETE_BTTN.Text = "REMOVE TEAM"
        Me.DELETE_BTTN.UseVisualStyleBackColor = True
        '
        'UPDATE_BTTN
        '
        Me.UPDATE_BTTN.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.89565!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.UPDATE_BTTN.Location = New System.Drawing.Point(227, 500)
        Me.UPDATE_BTTN.Margin = New System.Windows.Forms.Padding(4)
        Me.UPDATE_BTTN.Name = "UPDATE_BTTN"
        Me.UPDATE_BTTN.Size = New System.Drawing.Size(230, 30)
        Me.UPDATE_BTTN.TabIndex = 35
        Me.UPDATE_BTTN.Text = "UPDATE TEAM"
        Me.UPDATE_BTTN.UseVisualStyleBackColor = True
        '
        'CREATE_BTTN
        '
        Me.CREATE_BTTN.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.89565!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.CREATE_BTTN.Location = New System.Drawing.Point(227, 462)
        Me.CREATE_BTTN.Margin = New System.Windows.Forms.Padding(4)
        Me.CREATE_BTTN.Name = "CREATE_BTTN"
        Me.CREATE_BTTN.Size = New System.Drawing.Size(230, 30)
        Me.CREATE_BTTN.TabIndex = 34
        Me.CREATE_BTTN.Text = "REGISTER TEAM"
        Me.CREATE_BTTN.UseVisualStyleBackColor = True
        '
        'NEW_BTTN
        '
        Me.NEW_BTTN.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.01739!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.NEW_BTTN.Location = New System.Drawing.Point(500, 376)
        Me.NEW_BTTN.Margin = New System.Windows.Forms.Padding(4)
        Me.NEW_BTTN.Name = "NEW_BTTN"
        Me.NEW_BTTN.Size = New System.Drawing.Size(138, 39)
        Me.NEW_BTTN.TabIndex = 33
        Me.NEW_BTTN.Text = "CLEAR FORM"
        Me.NEW_BTTN.UseVisualStyleBackColor = True
        '
        'TEAMID_TB
        '
        Me.TEAMID_TB.Location = New System.Drawing.Point(131, 297)
        Me.TEAMID_TB.Name = "TEAMID_TB"
        Me.TEAMID_TB.Size = New System.Drawing.Size(121, 22)
        Me.TEAMID_TB.TabIndex = 37
        '
        'TEAMNAME_TB
        '
        Me.TEAMNAME_TB.Location = New System.Drawing.Point(131, 328)
        Me.TEAMNAME_TB.Name = "TEAMNAME_TB"
        Me.TEAMNAME_TB.Size = New System.Drawing.Size(179, 22)
        Me.TEAMNAME_TB.TabIndex = 38
        '
        'HEADCOACH_TB
        '
        Me.HEADCOACH_TB.Location = New System.Drawing.Point(459, 296)
        Me.HEADCOACH_TB.Name = "HEADCOACH_TB"
        Me.HEADCOACH_TB.Size = New System.Drawing.Size(207, 22)
        Me.HEADCOACH_TB.TabIndex = 40
        '
        'GENERALMANAGER_TB
        '
        Me.GENERALMANAGER_TB.Location = New System.Drawing.Point(459, 323)
        Me.GENERALMANAGER_TB.Name = "GENERALMANAGER_TB"
        Me.GENERALMANAGER_TB.Size = New System.Drawing.Size(207, 22)
        Me.GENERALMANAGER_TB.TabIndex = 42
        '
        'COUNTRY_CB
        '
        Me.COUNTRY_CB.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.COUNTRY_CB.FormattingEnabled = True
        Me.COUNTRY_CB.Items.AddRange(New Object() {"United States", "Canada", "Australia", "France", "Spain", "Germany", "Greece", "Serbia", "Croatia", "Slovenia", "Nigeria", "Cameroon", "Argentina", "Brazil", "China", "Lithuania", "Latvia", "Turkey", "Great Britain", "Russia", "Ukraine", "Italy", "Dominican Republic", "Puerto Rico", "Venezuela", "Mexico", "Poland", "Sweden", "Finland", "New Zealand", "Philippines", "Japan", "South Korea", "Iran", "Lebanon"})
        Me.COUNTRY_CB.Location = New System.Drawing.Point(131, 356)
        Me.COUNTRY_CB.Name = "COUNTRY_CB"
        Me.COUNTRY_CB.Size = New System.Drawing.Size(121, 24)
        Me.COUNTRY_CB.TabIndex = 43
        '
        'ESTABLISHEDYEAR_CB
        '
        Me.ESTABLISHEDYEAR_CB.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.ESTABLISHEDYEAR_CB.FormattingEnabled = True
        Me.ESTABLISHEDYEAR_CB.Items.AddRange(New Object() {"2010", "2011", "2012", "2013", "2014", "2015", "2016", "2017", "2018", "2019", "2020", "2021", "2022", "2023"})
        Me.ESTABLISHEDYEAR_CB.Location = New System.Drawing.Point(131, 391)
        Me.ESTABLISHEDYEAR_CB.Name = "ESTABLISHEDYEAR_CB"
        Me.ESTABLISHEDYEAR_CB.Size = New System.Drawing.Size(121, 24)
        Me.ESTABLISHEDYEAR_CB.TabIndex = 44
        '
        'CHAMPIONSHIP_NUD
        '
        Me.CHAMPIONSHIP_NUD.Location = New System.Drawing.Point(132, 421)
        Me.CHAMPIONSHIP_NUD.Name = "CHAMPIONSHIP_NUD"
        Me.CHAMPIONSHIP_NUD.Size = New System.Drawing.Size(120, 22)
        Me.CHAMPIONSHIP_NUD.TabIndex = 45
        '
        'SEARCH_BTTN
        '
        Me.SEARCH_BTTN.Location = New System.Drawing.Point(258, 296)
        Me.SEARCH_BTTN.Name = "SEARCH_BTTN"
        Me.SEARCH_BTTN.Size = New System.Drawing.Size(72, 23)
        Me.SEARCH_BTTN.TabIndex = 46
        Me.SEARCH_BTTN.Text = "Search"
        Me.SEARCH_BTTN.UseVisualStyleBackColor = True
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.Label8.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.27826!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label8.ForeColor = System.Drawing.SystemColors.Menu
        Me.Label8.Location = New System.Drawing.Point(8, 14)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(301, 30)
        Me.Label8.TabIndex = 47
        Me.Label8.Text = "TEAM REGISTRATION"
        '
        'Form_CRUD_Team
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(682, 585)
        Me.Controls.Add(Me.Label8)
        Me.Controls.Add(Me.SEARCH_BTTN)
        Me.Controls.Add(Me.CHAMPIONSHIP_NUD)
        Me.Controls.Add(Me.ESTABLISHEDYEAR_CB)
        Me.Controls.Add(Me.COUNTRY_CB)
        Me.Controls.Add(Me.GENERALMANAGER_TB)
        Me.Controls.Add(Me.HEADCOACH_TB)
        Me.Controls.Add(Me.TEAMNAME_TB)
        Me.Controls.Add(Me.TEAMID_TB)
        Me.Controls.Add(Me.DELETE_BTTN)
        Me.Controls.Add(Me.UPDATE_BTTN)
        Me.Controls.Add(Me.CREATE_BTTN)
        Me.Controls.Add(Me.NEW_BTTN)
        Me.Controls.Add(Me.Label7)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.DataGridView1)
        Me.Controls.Add(Me.Button1)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.Margin = New System.Windows.Forms.Padding(4)
        Me.Name = "Form_CRUD_Team"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Form_CRUD_Team"
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.CHAMPIONSHIP_NUD, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents Button1 As Button
    Friend WithEvents DataGridView1 As DataGridView
    Friend WithEvents Label1 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents Label5 As Label
    Friend WithEvents Label6 As Label
    Friend WithEvents Label7 As Label
    Friend WithEvents DELETE_BTTN As Button
    Friend WithEvents UPDATE_BTTN As Button
    Friend WithEvents CREATE_BTTN As Button
    Friend WithEvents NEW_BTTN As Button
    Friend WithEvents TEAMID_TB As TextBox
    Friend WithEvents TEAMNAME_TB As TextBox
    Friend WithEvents HEADCOACH_TB As TextBox
    Friend WithEvents GENERALMANAGER_TB As TextBox
    Friend WithEvents COUNTRY_CB As ComboBox
    Friend WithEvents ESTABLISHEDYEAR_CB As ComboBox
    Friend WithEvents CHAMPIONSHIP_NUD As NumericUpDown
    Friend WithEvents SEARCH_BTTN As Button
    Friend WithEvents Label8 As Label
End Class
