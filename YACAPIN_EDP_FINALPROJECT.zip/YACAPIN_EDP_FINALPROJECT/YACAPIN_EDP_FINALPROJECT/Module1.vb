﻿Imports System.Data.SqlClient
Imports System.Windows.Forms.VisualStyles.VisualStyleElement.Tab
Imports Microsoft.SqlServer.Server
Imports MySql.Data.MySqlClient
Module Module1

    Public _host As String = "localhost"
    Public _uname As String = "root"
    Public _password As String = ""
    Public _db As String = "db_aba"
    Public isConnected As Boolean
    Public myConn As New MySqlConnection
    Public myCmd As New MySqlCommand
    Public myAdap As New MySqlDataAdapter
    Public mytable As New DataTable
    Public remark As String


    Public Sub connectDB()
        If myConn.State = ConnectionState.Open Then
            Exit Sub
        Else

            myConn.ConnectionString = "Data source  =" & _host & "; User Id = " & _uname & ";Password = " & _password & "; database=" & _db & ""
            myConn.Open()
            myCmd.Connection = myConn
            isConnected = True
            MessageBox.Show("Database Connection Successful")
        End If



    End Sub

    Function getAllTeam_Players() As DataTable
        Dim PlayerTable As New DataTable
        Dim sql As String
        sql = "Select * From team_players"
        myCmd.CommandText = sql
        myCmd.Connection = myConn
        myAdap.SelectCommand = myCmd
        myAdap.Fill(PlayerTable)
        Return PlayerTable


    End Function
    Function getAllPlayerRecord() As DataTable
        Dim PlayerTable As New DataTable
        Dim sql As String
        sql = "Select * From players"
        myCmd.CommandText = sql
        myCmd.Connection = myConn
        myAdap.SelectCommand = myCmd
        myAdap.Fill(PlayerTable)
        Return PlayerTable


    End Function


    Function getAllPlayerAnalyticsRecord() As DataTable
        Dim PlayerAnalyticsTable As New DataTable
        Dim sql = "SELECT players.PlayerID, players.FirstName, players.LastName, players.DateOfBirth, players.Height, players.Weight, players.Nationality, players.Position, players.JerseyNumber, team_players.TeamName " &
                                      "FROM players " &
                                      "LEFT JOIN team_players ON players.PlayerId = team_players.PlayerId"

        myCmd.CommandText = sql
        myCmd.Connection = myConn
        myAdap.SelectCommand = myCmd
        myAdap.Fill(PlayerAnalyticsTable)
        Return PlayerAnalyticsTable

    End Function


    Function getAllTeamRecord() As DataTable
        Dim TeamTable As New DataTable
        Dim sql As String
        sql = "Select * From teams"
        myCmd.CommandText = sql
        myCmd.Connection = myConn
        myAdap.SelectCommand = myCmd
        myAdap.Fill(TeamTable)
        Return TeamTable


    End Function

    Function getAllTeamPlayer_PlayerListRecord() As DataTable
        Dim TeamTable As New DataTable
        Dim sql As String
        sql = "SELECT players.PlayerID, players.FirstName, players.LastName, players.DateOfBirth, players.Height, players.Weight, players.Nationality, players.Position, players.JerseyNumber " &
                      "FROM players " &
                      "LEFT JOIN team_players ON players.PlayerId = team_players.PlayerId " &
                      "WHERE team_players.TeamName IS NULL"
        myCmd.CommandText = sql
        myCmd.Connection = myConn
        myAdap.SelectCommand = myCmd
        myAdap.Fill(TeamTable)
        Return TeamTable


    End Function



    Function addPlayerInfo() As Boolean
        Module1.connectDB()
        Dim sql As String = "INSERT INTO players (PlayerID, FirstName, LastName, DateOfBirth, Height, Weight, Nationality, Position, JerseyNumber) " &
                        "VALUES (@PlayerID, @FirstName, @LastName, @DateOfBirth, @Height, @Weight, @Nationality,@Position,@JerseyNumber)"
        Dim result As Integer = 0

        Try


            Using myCmd As New MySqlCommand(sql, myConn)
                myCmd.Parameters.AddWithValue("@PlayerID", Form_CRUD_Player.PLAYERID_TB.Text)
                myCmd.Parameters.AddWithValue("@FirstName", Form_CRUD_Player.FIRSTNAME_TB.Text)
                myCmd.Parameters.AddWithValue("@LastName", Form_CRUD_Player.LASTNAME_TB.Text)
                myCmd.Parameters.AddWithValue("@DateOfBirth", Form_CRUD_Player.DateTimePicker_DATEOFBIRTH.Value.ToString("yyyy/MM/dd"))
                myCmd.Parameters.AddWithValue("@Height", Form_CRUD_Player.HEIGHT_CB.Text)
                myCmd.Parameters.AddWithValue("@Weight", Form_CRUD_Player.WEIGHT_CB.Text)
                myCmd.Parameters.AddWithValue("@Nationality", Form_CRUD_Player.NATIONALITY_CB.Text)
                myCmd.Parameters.AddWithValue("@Position", Form_CRUD_Player.POSITION_CB.Text)

                myCmd.Parameters.AddWithValue("@JerseyNumber", Form_CRUD_Player.JERSEYNUMBER_TB.Text)



                result = myCmd.ExecuteNonQuery()
            End Using

            Return result > 0
        Catch ex As Exception
            MessageBox.Show("Invalid Inputs")
            Return False
        End Try
    End Function



    Sub updateStudentRecord()
        Module1.connectDB()
        Dim sql As String = "UPDATE players SET " &
        "FirstName = @FirstName, " &
        "LastName = @LastName, " &
        "DateOfBirth = @DateOfBirth, " &
        "Height = @Height, " &
        "Weight = @Weight, " &
        "Nationality = @Nationality, " &
        "Position = @Position, " &
        "JerseyNumber = @JerseyNumber " &
        "WHERE PlayerID = @PlayerID"



        Dim result As Integer = 0

        Try


            Using myCmd As New MySqlCommand(sql, myConn)
                myCmd.Parameters.AddWithValue("@PlayerID", Form_CRUD_Player.PLAYERID_TB.Text)
                myCmd.Parameters.AddWithValue("@FirstName", Form_CRUD_Player.FIRSTNAME_TB.Text)
                myCmd.Parameters.AddWithValue("@LastName", Form_CRUD_Player.LASTNAME_TB.Text)
                myCmd.Parameters.AddWithValue("@DateOfBirth", Form_CRUD_Player.DateTimePicker_DATEOFBIRTH.Value.ToString("yyyy/MM/dd"))
                myCmd.Parameters.AddWithValue("@Height", Form_CRUD_Player.HEIGHT_CB.Text)
                myCmd.Parameters.AddWithValue("@Weight", Form_CRUD_Player.WEIGHT_CB.Text)
                myCmd.Parameters.AddWithValue("@Nationality", Form_CRUD_Player.NATIONALITY_CB.Text)
                myCmd.Parameters.AddWithValue("@Position", Form_CRUD_Player.POSITION_CB.Text)

                myCmd.Parameters.AddWithValue("@JerseyNumber", Form_CRUD_Player.JERSEYNUMBER_TB.Text)



                result = myCmd.ExecuteNonQuery()
            End Using


            If result > 0 Then
                remark = "Successful"
            Else
                MsgBox("Error executing the query", MsgBoxStyle.Exclamation)
            End If
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
    End Sub


    Sub deleteStudentRecord()
        Module1.connectDB()
        Dim sql As String = "DELETE FROM players WHERE PlayerID = @PlayerID"
        Dim result As Integer = 0

        Try

            Using myCmd As New MySqlCommand(sql, myConn)
                myCmd.Parameters.AddWithValue("@PlayerID", Form_CRUD_Player.PLAYERID_TB.Text)

                result = myCmd.ExecuteNonQuery()
            End Using


            If result > 0 Then
                remark = "Successful"
            Else
                MsgBox("Error executing the query", MsgBoxStyle.Exclamation)
            End If
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
    End Sub


    'ADDTEAM
    Function addTeamInfo() As Boolean
        Module1.connectDB()
        Dim sql As String = "INSERT INTO teams (TeamID, TeamName , Country, HeadCoach, EstablishedYear, Championships, GeneralManager) " &
                        "VALUES (@TeamID, @TeamName, @Country, @HeadCoach, @EstablishedYear, @Championships, @GeneralManager)"
        Dim result As Integer = 0

        Try


            Using myCmd As New MySqlCommand(sql, myConn)
                myCmd.Parameters.AddWithValue("@TeamID", Form_CRUD_Team.TEAMID_TB.Text)
                myCmd.Parameters.AddWithValue("@TeamName", Form_CRUD_Team.TEAMNAME_TB.Text)
                myCmd.Parameters.AddWithValue("@Country", Form_CRUD_Team.COUNTRY_CB.Text)
                myCmd.Parameters.AddWithValue("@HeadCoach", Form_CRUD_Team.HEADCOACH_TB.Text)
                myCmd.Parameters.AddWithValue("@EstablishedYear", Form_CRUD_Team.ESTABLISHEDYEAR_CB.Text)
                myCmd.Parameters.AddWithValue("@Championships", Form_CRUD_Team.CHAMPIONSHIP_NUD.Value.ToString)
                myCmd.Parameters.AddWithValue("@GeneralManager", Form_CRUD_Team.GENERALMANAGER_TB.Text)

                result = myCmd.ExecuteNonQuery()
            End Using

            Return result > 0
        Catch ex As Exception
            MessageBox.Show("Invalid Inputs")
            Return False
        End Try
    End Function


    Sub updateTeamRecord()
        Module1.connectDB()
        Dim sql As String = "UPDATE teams SET " &
        "TeamName = @TeamName, " &
        "Country = @Country, " &
        "HeadCoach = @HeadCoach, " &
        "EstablishedYear = @EstablishedYear, " &
        "Championships = @Championships, " &
        "GeneralManager = @GeneralManager " &
        "WHERE TeamID = @TeamID"

        Dim result As Integer = 0

        Try
            Using myCmd As New MySqlCommand(sql, myConn)
                myCmd.Parameters.AddWithValue("@TeamID", Form_CRUD_Team.TEAMID_TB.Text)
                myCmd.Parameters.AddWithValue("@TeamName", Form_CRUD_Team.TEAMNAME_TB.Text)
                myCmd.Parameters.AddWithValue("@Country", Form_CRUD_Team.COUNTRY_CB.Text)
                myCmd.Parameters.AddWithValue("@HeadCoach", Form_CRUD_Team.HEADCOACH_TB.Text)
                myCmd.Parameters.AddWithValue("@EstablishedYear", Form_CRUD_Team.ESTABLISHEDYEAR_CB.Text)
                myCmd.Parameters.AddWithValue("@Championships", Form_CRUD_Team.CHAMPIONSHIP_NUD.Value.ToString)
                myCmd.Parameters.AddWithValue("@GeneralManager", Form_CRUD_Team.GENERALMANAGER_TB.Text)
                result = myCmd.ExecuteNonQuery()
            End Using

            If result > 0 Then
                remark = "Successful"
            Else
                MsgBox("Error executing the query", MsgBoxStyle.Exclamation)
            End If
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
    End Sub



    Sub deleteteamRecord()
        Module1.connectDB()
        Dim sql As String = "DELETE FROM teams WHERE TeamID = @TeamID; DELETE FROM team_players WHERE TeamName = @TeamName"
        Dim result As Integer = 0

        Try
            Using myCmd As New MySqlCommand(sql, myConn)
                myCmd.Parameters.AddWithValue("@TeamID", Form_CRUD_Team.TEAMID_TB.Text)
                myCmd.Parameters.AddWithValue("@TeamName", Form_CRUD_Team.TEAMNAME_TB.Text)

                result = myCmd.ExecuteNonQuery()
            End Using

            If result > 0 Then
                remark = "Successful"
            Else
                MsgBox("Error executing the query", MsgBoxStyle.Exclamation)
            End If
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
    End Sub
    Sub LoadTeamsIntoComboBox()
        Module1.connectDB()
        Dim sql As String = "SELECT TeamID, TeamName FROM teams"

        Using myCmd As New MySqlCommand(sql, myConn)
            Using reader As MySqlDataReader = myCmd.ExecuteReader()
                ' Clear existing items from the combobox
                Form_PlayertoTeam.TEAMNAME_CB.Items.Clear()

                ' Loop through the retrieved data and add items to the combobox
                While reader.Read()
                    Dim teamID As Integer = CInt(reader("TeamID"))
                    Dim teamName As String = reader("TeamName").ToString()
                    Dim teamItem As New With {.ID = teamID, .Name = teamName}

                    teamItem.ToString()

                    ' Add the teamItem to the combobox items
                    Form_PlayertoTeam.TEAMNAME_CB.Items.Add(teamItem.Name)
                    Form_PlayertoTeam.TEAMID_CB.Items.Add(teamItem.ID)
                End While

                ' Close the reader
                reader.Close()
            End Using
        End Using
    End Sub


    Sub deleteteam_playerRecord()
        Module1.connectDB()
        Dim sql As String = "DELETE FROM team_players WHERE PlayerID= @PlayerID"
        Dim result As Integer = 0

        Try

            Using myCmd As New MySqlCommand(sql, myConn)
                myCmd.Parameters.AddWithValue("@PlayerID", Form_PlayertoTeam.PLAYERID_TB.Text)

                result = myCmd.ExecuteNonQuery()
            End Using


            If result > 0 Then
                remark = "Successful"
            Else
                MsgBox("Error executing the query", MsgBoxStyle.Exclamation)
            End If
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
    End Sub



    Function addteam_playerRecord() As Boolean
        Module1.connectDB()
        Dim sql As String = "INSERT INTO team_players (TeamName,TeamID, PlayerId, PlayerFirstName, PlayerLastName, Salary) " &
                        "VALUES (@TeamName, @TeamID, @PlayerId, @PlayerFirstName, @PlayerLastName, @Salary)"
        Dim result As Integer = 0

        Try


            Using myCmd As New MySqlCommand(sql, myConn)


                myCmd.Parameters.AddWithValue("@TeamName", Form_PlayertoTeam.TEAMNAME_CB.Text)
                myCmd.Parameters.AddWithValue("@TeamID", Form_PlayertoTeam.TEAMID_CB.Text)

                myCmd.Parameters.AddWithValue("@PlayerId", Form_PlayertoTeam.PLAYERID_TB.Text)
                myCmd.Parameters.AddWithValue("@PlayerFirstName", Form_PlayertoTeam.FIRSTNAME_TB.Text)
                myCmd.Parameters.AddWithValue("@PlayerLastName", Form_PlayertoTeam.LASTNAME_TB.Text)

                myCmd.Parameters.AddWithValue("@Salary", Form_PlayertoTeam.SALARY_TB.Text)




                result = myCmd.ExecuteNonQuery()
            End Using

            Return result > 0
        Catch ex As Exception
            MessageBox.Show("Invalid Inputs")
            Return False
        End Try
    End Function




End Module
