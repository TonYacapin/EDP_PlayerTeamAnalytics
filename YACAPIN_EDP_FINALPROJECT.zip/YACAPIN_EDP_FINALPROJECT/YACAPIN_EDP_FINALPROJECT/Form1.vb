﻿Public Class Form1


    Dim player_table As DataTable

    Dim team_table As DataTable

    Dim team_players As DataTable
    Private Sub AllPlayersToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles AllPlayersToolStripMenuItem.Click




        Form_PlayerAnalytics.Show()

        player_table = getAllPlayerAnalyticsRecord()

        Form_PlayerAnalytics.DataGridView1.DataSource = player_table

        Me.Hide()
    End Sub

    Private Sub AllTeamsToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles AllTeamsToolStripMenuItem.Click
        Form_TeamANALYTICS.Show()


        team_table = getAllTeamRecord()


        Form_TeamANALYTICS.DataGridView1.DataSource = team_table


        Me.Hide()
    End Sub

    Private Sub TeamToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles TeamToolStripMenuItem.Click
        Form_CRUD_Team.Show()

        team_table = getAllTeamRecord()


        Form_CRUD_Team.DataGridView1.DataSource = team_table


        Me.Hide()

    End Sub

    Private Sub PlayerToolStripMenuItem1_Click(sender As Object, e As EventArgs) Handles PlayerToolStripMenuItem1.Click
        Form_CRUD_Player.Show()


        player_table = getAllPlayerRecord()

        Form_CRUD_Player.DataGridView1.DataSource = player_table

        Me.Hide()
    End Sub

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        connectDB()
    End Sub

    Private Sub PlayerToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles PlayerToolStripMenuItem.Click



    End Sub

    Private Sub PlayerToTeamToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles PlayerToTeamToolStripMenuItem.Click
        Form_PlayertoTeam.Show()

        team_players = getAllTeam_Players()
        player_table = getAllTeamPlayer_PlayerListRecord()

        Form_PlayertoTeam.DataGridView1.DataSource = player_table
        Form_PlayertoTeam.DataGridView2.DataSource = team_players



        Me.Hide()

    End Sub

    Private Sub MODELToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles MODELToolStripMenuItem.Click
        Form_ERDMODEL.Show()
        Me.Hide()
    End Sub
End Class
