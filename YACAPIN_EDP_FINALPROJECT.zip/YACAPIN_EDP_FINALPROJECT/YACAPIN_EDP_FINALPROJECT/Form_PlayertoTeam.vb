﻿Imports MySql.Data.MySqlClient

Public Class Form_PlayertoTeam
    Private Sub Form_PlayertoTeam_Load(sender As Object, e As EventArgs) Handles MyBase.Load

        LoadTeamsIntoComboBox()

    End Sub

    Private Sub ASSIGNPLAYER_BTTN_Click(sender As Object, e As EventArgs) Handles ASSIGNPLAYER_BTTN.Click

        If TEAMNAME_CB.Text <> "" And SALARY_TB.Text <> "" Then

            addteam_playerRecord()

        Else
            MessageBox.Show("Select Team and Input Salary")
        End If




        Dim teamplayer_table = getAllTeam_Players()

        Me.DataGridView2.DataSource = teamplayer_table




        Dim player_table = getAllTeamPlayer_PlayerListRecord()




        Me.DataGridView1.DataSource = player_table


    End Sub

    Sub FormRefresh()

        Dim player_table As DataTable


        player_table = getAllTeamPlayer_PlayerListRecord()




        Me.DataGridView1.DataSource = player_table




        Dim team_players_table As DataTable


        team_players_table = getAllTeam_Players()






        Me.DataGridView2.DataSource = team_players_table

    End Sub



    Private Sub DataGridView1_CellContentClick(sender As Object, e As DataGridViewCellEventArgs) Handles DataGridView1.CellContentClick


        TEAMNAME_CB.SelectedIndex = -1
        SALARY_TB.Clear()

        If e.ColumnIndex >= 0 AndAlso e.RowIndex >= 0 Then
            PLAYERID_TB.Text = DataGridView1.Rows(e.RowIndex).Cells(0).Value
            FIRSTNAME_TB.Text = DataGridView1.Rows(e.RowIndex).Cells(1).Value
            LASTNAME_TB.Text = DataGridView1.Rows(e.RowIndex).Cells(2).Value







        End If

    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Form1.Show()
        Me.Close()

    End Sub

    Private Sub DataGridView2_CellContentClick(sender As Object, e As DataGridViewCellEventArgs) Handles DataGridView2.CellContentClick


        TEAMNAME_CB.SelectedIndex = -1
        SALARY_TB.Clear()

        If e.ColumnIndex >= 0 AndAlso e.RowIndex >= 0 Then
            TEAMNAME_CB.Text = DataGridView2.Rows(e.RowIndex).Cells(0).Value
            TEAMID_CB.Text = DataGridView2.Rows(e.RowIndex).Cells(1).Value
            PLAYERID_TB.Text = DataGridView2.Rows(e.RowIndex).Cells(2).Value
            FIRSTNAME_TB.Text = DataGridView2.Rows(e.RowIndex).Cells(3).Value
            LASTNAME_TB.Text = DataGridView2.Rows(e.RowIndex).Cells(4).Value
            SALARY_TB.Text = DataGridView2.Rows(e.RowIndex).Cells(5).Value








        End If
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click



        deleteteam_playerRecord()


        FormRefresh()


    End Sub

    Private Sub TEAMNAME_CB_SelectedIndexChanged(sender As Object, e As EventArgs) Handles TEAMNAME_CB.SelectedIndexChanged
        TEAMID_CB.SelectedIndex = TEAMNAME_CB.SelectedIndex
    End Sub


    Private Sub SEARCH_BTTN_Click(sender As Object, e As EventArgs) Handles SEARCH_BTTN.Click


        TEAMNAME_CB.SelectedIndex = -1
        SALARY_TB.Clear()

        Dim playerId As String = PLAYERID_TB.Text

        If String.IsNullOrEmpty(playerId) Then
            MessageBox.Show("Please enter a Player ID.")
            Return
        End If

        Try
            Module1.connectDB()

            Dim sql As String = "SELECT players.PlayerID, players.FirstName, players.LastName, team_players.TeamName, team_players.TeamID, team_players.Salary " &
                       "FROM players " &
                       "LEFT JOIN team_players ON players.PlayerId = team_players.PlayerId " &
                       "WHERE players.PlayerID = @PlayerID"

            Using myCmd As New MySqlCommand(sql, myConn)
                myCmd.Parameters.AddWithValue("@PlayerID", playerId)

                Using reader As MySqlDataReader = myCmd.ExecuteReader()
                    If reader.Read() Then
                        FIRSTNAME_TB.Text = reader("FirstName").ToString()
                        LASTNAME_TB.Text = reader("LastName").ToString()
                        TEAMID_CB.Text = reader("TeamID").ToString()
                        TEAMNAME_CB.Text = reader("TeamName").ToString()
                        SALARY_TB.Text = reader("Salary").ToString()

                        MessageBox.Show("Player found.")
                    Else
                        MessageBox.Show("Player not found.")
                    End If
                End Using
            End Using
        Catch ex As Exception
            MessageBox.Show("An error occurred: " & ex.Message)
        End Try
    End Sub

End Class