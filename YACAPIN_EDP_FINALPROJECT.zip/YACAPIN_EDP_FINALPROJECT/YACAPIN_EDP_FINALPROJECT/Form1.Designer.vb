﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Form1))
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.MenuStrip1 = New System.Windows.Forms.MenuStrip()
        Me.MenuToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.PlayerToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.AllPlayersToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.TeamsToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.AllTeamsToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.AddToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.PlayerToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.TeamToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.AssignPlayerToTeamToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.PlayerToTeamToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ERDToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.MODELToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.MenuStrip1.SuspendLayout()
        Me.SuspendLayout()
        '
        'PictureBox1
        '
        Me.PictureBox1.BackgroundImage = CType(resources.GetObject("PictureBox1.BackgroundImage"), System.Drawing.Image)
        Me.PictureBox1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.PictureBox1.Location = New System.Drawing.Point(0, 32)
        Me.PictureBox1.Margin = New System.Windows.Forms.Padding(4)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(664, 405)
        Me.PictureBox1.TabIndex = 0
        Me.PictureBox1.TabStop = False
        '
        'MenuStrip1
        '
        Me.MenuStrip1.BackColor = System.Drawing.Color.White
        Me.MenuStrip1.ImageScalingSize = New System.Drawing.Size(19, 19)
        Me.MenuStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.MenuToolStripMenuItem, Me.PlayerToolStripMenuItem, Me.TeamsToolStripMenuItem, Me.AddToolStripMenuItem, Me.AssignPlayerToTeamToolStripMenuItem, Me.ERDToolStripMenuItem})
        Me.MenuStrip1.Location = New System.Drawing.Point(0, 0)
        Me.MenuStrip1.Name = "MenuStrip1"
        Me.MenuStrip1.Padding = New System.Windows.Forms.Padding(8, 2, 0, 2)
        Me.MenuStrip1.Size = New System.Drawing.Size(664, 28)
        Me.MenuStrip1.TabIndex = 2
        Me.MenuStrip1.Text = "MenuStrip1"
        '
        'MenuToolStripMenuItem
        '
        Me.MenuToolStripMenuItem.Name = "MenuToolStripMenuItem"
        Me.MenuToolStripMenuItem.Size = New System.Drawing.Size(64, 24)
        Me.MenuToolStripMenuItem.Text = "Home"
        '
        'PlayerToolStripMenuItem
        '
        Me.PlayerToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.AllPlayersToolStripMenuItem})
        Me.PlayerToolStripMenuItem.Name = "PlayerToolStripMenuItem"
        Me.PlayerToolStripMenuItem.Size = New System.Drawing.Size(63, 24)
        Me.PlayerToolStripMenuItem.Text = "Player"
        '
        'AllPlayersToolStripMenuItem
        '
        Me.AllPlayersToolStripMenuItem.Name = "AllPlayersToolStripMenuItem"
        Me.AllPlayersToolStripMenuItem.Size = New System.Drawing.Size(159, 26)
        Me.AllPlayersToolStripMenuItem.Text = "All Players"
        '
        'TeamsToolStripMenuItem
        '
        Me.TeamsToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.AllTeamsToolStripMenuItem})
        Me.TeamsToolStripMenuItem.Name = "TeamsToolStripMenuItem"
        Me.TeamsToolStripMenuItem.Size = New System.Drawing.Size(65, 24)
        Me.TeamsToolStripMenuItem.Text = "Teams"
        '
        'AllTeamsToolStripMenuItem
        '
        Me.AllTeamsToolStripMenuItem.Name = "AllTeamsToolStripMenuItem"
        Me.AllTeamsToolStripMenuItem.Size = New System.Drawing.Size(155, 26)
        Me.AllTeamsToolStripMenuItem.Text = "All Teams"
        '
        'AddToolStripMenuItem
        '
        Me.AddToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.PlayerToolStripMenuItem1, Me.TeamToolStripMenuItem})
        Me.AddToolStripMenuItem.Name = "AddToolStripMenuItem"
        Me.AddToolStripMenuItem.Size = New System.Drawing.Size(66, 24)
        Me.AddToolStripMenuItem.Text = "Create"
        '
        'PlayerToolStripMenuItem1
        '
        Me.PlayerToolStripMenuItem1.Name = "PlayerToolStripMenuItem1"
        Me.PlayerToolStripMenuItem1.Size = New System.Drawing.Size(131, 26)
        Me.PlayerToolStripMenuItem1.Text = "Player"
        '
        'TeamToolStripMenuItem
        '
        Me.TeamToolStripMenuItem.Name = "TeamToolStripMenuItem"
        Me.TeamToolStripMenuItem.Size = New System.Drawing.Size(131, 26)
        Me.TeamToolStripMenuItem.Text = "Team"
        '
        'AssignPlayerToTeamToolStripMenuItem
        '
        Me.AssignPlayerToTeamToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.PlayerToTeamToolStripMenuItem})
        Me.AssignPlayerToTeamToolStripMenuItem.Name = "AssignPlayerToTeamToolStripMenuItem"
        Me.AssignPlayerToTeamToolStripMenuItem.Size = New System.Drawing.Size(70, 24)
        Me.AssignPlayerToTeamToolStripMenuItem.Text = "Assign "
        '
        'PlayerToTeamToolStripMenuItem
        '
        Me.PlayerToTeamToolStripMenuItem.Name = "PlayerToTeamToolStripMenuItem"
        Me.PlayerToTeamToolStripMenuItem.Size = New System.Drawing.Size(217, 26)
        Me.PlayerToTeamToolStripMenuItem.Text = "Player to Team"
        '
        'ERDToolStripMenuItem
        '
        Me.ERDToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.MODELToolStripMenuItem})
        Me.ERDToolStripMenuItem.Name = "ERDToolStripMenuItem"
        Me.ERDToolStripMenuItem.Size = New System.Drawing.Size(51, 24)
        Me.ERDToolStripMenuItem.Text = "ERD"
        '
        'MODELToolStripMenuItem
        '
        Me.MODELToolStripMenuItem.Name = "MODELToolStripMenuItem"
        Me.MODELToolStripMenuItem.Size = New System.Drawing.Size(217, 26)
        Me.MODELToolStripMenuItem.Text = "Model"
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.BurlyWood
        Me.ClientSize = New System.Drawing.Size(664, 437)
        Me.Controls.Add(Me.PictureBox1)
        Me.Controls.Add(Me.MenuStrip1)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.MainMenuStrip = Me.MenuStrip1
        Me.Margin = New System.Windows.Forms.Padding(4)
        Me.Name = "Form1"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Form1"
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.MenuStrip1.ResumeLayout(False)
        Me.MenuStrip1.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents PictureBox1 As PictureBox
    Friend WithEvents MenuStrip1 As MenuStrip
    Friend WithEvents MenuToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents PlayerToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents TeamsToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents AllPlayersToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents AllTeamsToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents AddToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents PlayerToolStripMenuItem1 As ToolStripMenuItem
    Friend WithEvents TeamToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents AssignPlayerToTeamToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents PlayerToTeamToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents ERDToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents MODELToolStripMenuItem As ToolStripMenuItem
End Class
