﻿Imports Microsoft.VisualBasic.Devices
Imports MySql.Data.MySqlClient

Public Class Form_CRUD_Player

    Dim player_table As DataTable
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Form1.Show()
        Me.Close()

    End Sub

    Private Sub Label1_Click(sender As Object, e As EventArgs) Handles Label1.Click

    End Sub

    Private Sub Label6_Click(sender As Object, e As EventArgs) Handles Label6.Click

    End Sub

    Private Sub CREATE_BTTN_Click(sender As Object, e As EventArgs) Handles CREATE_BTTN.Click
        addPlayerInfo()

        Dim player_table = getAllPlayerRecord()

        Me.DataGridView1.DataSource = player_table

    End Sub

    Private Sub DateTimePicker_DATEOFBIRTH_ValueChanged(sender As Object, e As EventArgs) Handles DateTimePicker_DATEOFBIRTH.ValueChanged

    End Sub

    Private Sub UPDATE_BTTN_Click(sender As Object, e As EventArgs) Handles UPDATE_BTTN.Click
        If PLAYERID_TB.Text <> "" Then
            updateStudentRecord()
            If remark = "Successful" Then
                MsgBox("Student Record Seuccessfully Updated")
                FormRefresh()

            End If
        Else
            MsgBox("Please Search Student Record to the updated")
        End If
    End Sub


    Sub FormRefresh()
        Dim player_table As DataTable


        player_table = getAllPlayerRecord()

        Me.DataGridView1.DataSource = player_table


    End Sub

    Private Sub SEARCH_BTTN_Click(sender As Object, e As EventArgs) Handles SEARCH_BTTN.Click



        Dim playerId As String = PLAYERID_TB.Text
        If String.IsNullOrEmpty(playerId) Then
            MessageBox.Show("Please enter a Player ID.")
            Return
        End If

        Try
            Module1.connectDB()

            Dim sql As String = "SELECT * FROM players WHERE PlayerID = @PlayerID"

            Using myCmd As New MySqlCommand(sql, myConn)
                myCmd.Parameters.AddWithValue("@PlayerID", playerId)

                Using reader As MySqlDataReader = myCmd.ExecuteReader()
                    If reader.Read() Then


                        FIRSTNAME_TB.Text = reader("FirstName").ToString()
                        LASTNAME_TB.Text = reader("LastName").ToString()
                        DateTimePicker_DATEOFBIRTH.Value = Convert.ToDateTime(reader("DateOfBirth"))
                        HEIGHT_CB.Text = reader("Height").ToString()
                        WEIGHT_CB.SelectedText = reader("Weight").ToString()




                        NATIONALITY_CB.Text = reader("Nationality").ToString()
                        POSITION_CB.Text = reader("Position").ToString()

                        JERSEYNUMBER_TB.Text = reader("JerseyNumber").ToString()
                     

                        MessageBox.Show("Player found.")
                    Else
                        MessageBox.Show("Player not found.")
                    End If
                End Using
            End Using
        Catch ex As Exception
            MessageBox.Show("An error occurred: " & ex.Message)
        End Try


    End Sub

    Private Sub DataGridView1_CellContentClick(sender As Object, e As DataGridViewCellEventArgs) Handles DataGridView1.CellContentClick



        If e.ColumnIndex >= 0 AndAlso e.RowIndex >= 0 Then
            PLAYERID_TB.Text = DataGridView1.Rows(e.RowIndex).Cells(0).Value
            FIRSTNAME_TB.Text = DataGridView1.Rows(e.RowIndex).Cells(1).Value
            LASTNAME_TB.Text = DataGridView1.Rows(e.RowIndex).Cells(2).Value
            DateTimePicker_DATEOFBIRTH.Text = DataGridView1.Rows(e.RowIndex).Cells(3).Value
            HEIGHT_CB.Text = DataGridView1.Rows(e.RowIndex).Cells(4).Value
            WEIGHT_CB.Text = DataGridView1.Rows(e.RowIndex).Cells(5).Value
            NATIONALITY_CB.Text = DataGridView1.Rows(e.RowIndex).Cells(6).Value
            POSITION_CB.Text = DataGridView1.Rows(e.RowIndex).Cells(7).Value
            JERSEYNUMBER_TB.Text = DataGridView1.Rows(e.RowIndex).Cells(8).Value





        End If


    End Sub

    Private Sub DELETE_BTTN_Click(sender As Object, e As EventArgs) Handles DELETE_BTTN.Click
        deleteStudentRecord()


        FormRefresh()



    End Sub

    Private Sub Form_CRUD_Player_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        LoadTeamsIntoComboBox()
    End Sub

    Private Sub NEW_BTTN_Click(sender As Object, e As EventArgs) Handles NEW_BTTN.Click
        FIRSTNAME_TB.Clear()
        JERSEYNUMBER_TB.Clear()
        LASTNAME_TB.Clear()
        PLAYERID_TB.Clear()


        HEIGHT_CB.Text = ""
        WEIGHT_CB.Text = ""
        NATIONALITY_CB.SelectedIndex = -1
        POSITION_CB.SelectedIndex = -1



    End Sub

    Private Sub TEAMID_CB_SelectedIndexChanged(sender As Object, e As EventArgs)

    End Sub

    Private Sub HEIGHT_CB_SelectedIndexChanged(sender As Object, e As EventArgs) Handles HEIGHT_CB.SelectedIndexChanged

    End Sub
End Class