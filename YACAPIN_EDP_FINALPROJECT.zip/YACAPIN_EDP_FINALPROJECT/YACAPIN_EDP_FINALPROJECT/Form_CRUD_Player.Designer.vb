﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class Form_CRUD_Player
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.DataGridView1 = New System.Windows.Forms.DataGridView()
        Me.PLAYERID_TB = New System.Windows.Forms.TextBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.FIRSTNAME_TB = New System.Windows.Forms.TextBox()
        Me.LASTNAME_TB = New System.Windows.Forms.TextBox()
        Me.JERSEYNUMBER_TB = New System.Windows.Forms.TextBox()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.NEW_BTTN = New System.Windows.Forms.Button()
        Me.CREATE_BTTN = New System.Windows.Forms.Button()
        Me.UPDATE_BTTN = New System.Windows.Forms.Button()
        Me.DELETE_BTTN = New System.Windows.Forms.Button()
        Me.SEARCH_BTTN = New System.Windows.Forms.Button()
        Me.DateTimePicker_DATEOFBIRTH = New System.Windows.Forms.DateTimePicker()
        Me.HEIGHT_CB = New System.Windows.Forms.ComboBox()
        Me.WEIGHT_CB = New System.Windows.Forms.ComboBox()
        Me.NATIONALITY_CB = New System.Windows.Forms.ComboBox()
        Me.POSITION_CB = New System.Windows.Forms.ComboBox()
        Me.Label8 = New System.Windows.Forms.Label()
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'Button1
        '
        Me.Button1.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.89565!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button1.Location = New System.Drawing.Point(439, 23)
        Me.Button1.Margin = New System.Windows.Forms.Padding(4)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(230, 39)
        Me.Button1.TabIndex = 3
        Me.Button1.Text = "MAIN MENU"
        Me.Button1.UseVisualStyleBackColor = True
        '
        'DataGridView1
        '
        Me.DataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DataGridView1.Location = New System.Drawing.Point(16, 87)
        Me.DataGridView1.Margin = New System.Windows.Forms.Padding(4)
        Me.DataGridView1.Name = "DataGridView1"
        Me.DataGridView1.RowHeadersWidth = 49
        Me.DataGridView1.Size = New System.Drawing.Size(653, 219)
        Me.DataGridView1.TabIndex = 4
        '
        'PLAYERID_TB
        '
        Me.PLAYERID_TB.Location = New System.Drawing.Point(115, 334)
        Me.PLAYERID_TB.Margin = New System.Windows.Forms.Padding(4)
        Me.PLAYERID_TB.Name = "PLAYERID_TB"
        Me.PLAYERID_TB.Size = New System.Drawing.Size(171, 22)
        Me.PLAYERID_TB.TabIndex = 5
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(15, 342)
        Me.Label1.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(59, 16)
        Me.Label1.TabIndex = 6
        Me.Label1.Text = "PlayerID"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(15, 383)
        Me.Label2.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(69, 16)
        Me.Label2.TabIndex = 7
        Me.Label2.Text = "FirstName"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(15, 424)
        Me.Label3.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(69, 16)
        Me.Label3.TabIndex = 8
        Me.Label3.Text = "LastName"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(15, 464)
        Me.Label4.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(75, 16)
        Me.Label4.TabIndex = 9
        Me.Label4.Text = "DateOfBirth"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(15, 505)
        Me.Label5.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(46, 16)
        Me.Label5.TabIndex = 10
        Me.Label5.Text = "Height"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(15, 537)
        Me.Label6.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(49, 16)
        Me.Label6.TabIndex = 11
        Me.Label6.Text = "Weight"
        '
        'FIRSTNAME_TB
        '
        Me.FIRSTNAME_TB.Location = New System.Drawing.Point(115, 374)
        Me.FIRSTNAME_TB.Margin = New System.Windows.Forms.Padding(4)
        Me.FIRSTNAME_TB.Name = "FIRSTNAME_TB"
        Me.FIRSTNAME_TB.Size = New System.Drawing.Size(171, 22)
        Me.FIRSTNAME_TB.TabIndex = 12
        '
        'LASTNAME_TB
        '
        Me.LASTNAME_TB.Location = New System.Drawing.Point(115, 415)
        Me.LASTNAME_TB.Margin = New System.Windows.Forms.Padding(4)
        Me.LASTNAME_TB.Name = "LASTNAME_TB"
        Me.LASTNAME_TB.Size = New System.Drawing.Size(171, 22)
        Me.LASTNAME_TB.TabIndex = 13
        '
        'JERSEYNUMBER_TB
        '
        Me.JERSEYNUMBER_TB.Location = New System.Drawing.Point(516, 415)
        Me.JERSEYNUMBER_TB.Margin = New System.Windows.Forms.Padding(4)
        Me.JERSEYNUMBER_TB.Name = "JERSEYNUMBER_TB"
        Me.JERSEYNUMBER_TB.Size = New System.Drawing.Size(121, 22)
        Me.JERSEYNUMBER_TB.TabIndex = 26
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Location = New System.Drawing.Point(403, 418)
        Me.Label9.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(96, 16)
        Me.Label9.TabIndex = 21
        Me.Label9.Text = "JerseyNumber"
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Location = New System.Drawing.Point(403, 383)
        Me.Label11.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(55, 16)
        Me.Label11.TabIndex = 19
        Me.Label11.Text = "Position"
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.Location = New System.Drawing.Point(403, 342)
        Me.Label12.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(70, 16)
        Me.Label12.TabIndex = 18
        Me.Label12.Text = "Nationality"
        '
        'NEW_BTTN
        '
        Me.NEW_BTTN.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.01739!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.NEW_BTTN.Location = New System.Drawing.Point(439, 482)
        Me.NEW_BTTN.Margin = New System.Windows.Forms.Padding(4)
        Me.NEW_BTTN.Name = "NEW_BTTN"
        Me.NEW_BTTN.Size = New System.Drawing.Size(138, 39)
        Me.NEW_BTTN.TabIndex = 29
        Me.NEW_BTTN.Text = "CLEAR FORM"
        Me.NEW_BTTN.UseVisualStyleBackColor = True
        '
        'CREATE_BTTN
        '
        Me.CREATE_BTTN.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.89565!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.CREATE_BTTN.Location = New System.Drawing.Point(213, 591)
        Me.CREATE_BTTN.Margin = New System.Windows.Forms.Padding(4)
        Me.CREATE_BTTN.Name = "CREATE_BTTN"
        Me.CREATE_BTTN.Size = New System.Drawing.Size(235, 28)
        Me.CREATE_BTTN.TabIndex = 30
        Me.CREATE_BTTN.Text = "REGISTER PLAYER"
        Me.CREATE_BTTN.UseVisualStyleBackColor = True
        '
        'UPDATE_BTTN
        '
        Me.UPDATE_BTTN.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.89565!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.UPDATE_BTTN.Location = New System.Drawing.Point(213, 627)
        Me.UPDATE_BTTN.Margin = New System.Windows.Forms.Padding(4)
        Me.UPDATE_BTTN.Name = "UPDATE_BTTN"
        Me.UPDATE_BTTN.Size = New System.Drawing.Size(235, 28)
        Me.UPDATE_BTTN.TabIndex = 31
        Me.UPDATE_BTTN.Text = "UPDATE PLAYER"
        Me.UPDATE_BTTN.UseVisualStyleBackColor = True
        '
        'DELETE_BTTN
        '
        Me.DELETE_BTTN.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.89565!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.DELETE_BTTN.Location = New System.Drawing.Point(213, 663)
        Me.DELETE_BTTN.Margin = New System.Windows.Forms.Padding(4)
        Me.DELETE_BTTN.Name = "DELETE_BTTN"
        Me.DELETE_BTTN.Size = New System.Drawing.Size(235, 28)
        Me.DELETE_BTTN.TabIndex = 32
        Me.DELETE_BTTN.Text = "REMOVE PLAYER"
        Me.DELETE_BTTN.UseVisualStyleBackColor = True
        '
        'SEARCH_BTTN
        '
        Me.SEARCH_BTTN.Location = New System.Drawing.Point(321, 334)
        Me.SEARCH_BTTN.Margin = New System.Windows.Forms.Padding(4)
        Me.SEARCH_BTTN.Name = "SEARCH_BTTN"
        Me.SEARCH_BTTN.Size = New System.Drawing.Size(74, 28)
        Me.SEARCH_BTTN.TabIndex = 33
        Me.SEARCH_BTTN.Text = "Search"
        Me.SEARCH_BTTN.UseVisualStyleBackColor = True
        '
        'DateTimePicker_DATEOFBIRTH
        '
        Me.DateTimePicker_DATEOFBIRTH.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.DateTimePicker_DATEOFBIRTH.Location = New System.Drawing.Point(115, 454)
        Me.DateTimePicker_DATEOFBIRTH.Margin = New System.Windows.Forms.Padding(4)
        Me.DateTimePicker_DATEOFBIRTH.Name = "DateTimePicker_DATEOFBIRTH"
        Me.DateTimePicker_DATEOFBIRTH.Size = New System.Drawing.Size(171, 22)
        Me.DateTimePicker_DATEOFBIRTH.TabIndex = 34
        '
        'HEIGHT_CB
        '
        Me.HEIGHT_CB.FormattingEnabled = True
        Me.HEIGHT_CB.Items.AddRange(New Object() {"5'0"" (152 cm)", "5'1"" (155 cm)", "5'2"" (157 cm)", "5'3"" (160 cm)", "5'4"" (163 cm)", "5'5"" (165 cm)", "5'6"" (168 cm)", "5'7"" (170 cm)", "5'8"" (173 cm)", "5'9"" (175 cm)", "5'10"" (178 cm)", "5'11"" (180 cm)", "6'0"" (183 cm)", "6'1"" (185 cm)", "6'2"" (188 cm)", "6'3"" (191 cm)", "6'4"" (193 cm)", "6'5"" (196 cm)", "6'6"" (198 cm)", "6'7"" (201 cm)", "6'8"" (203 cm)", "6'9"" (206 cm)", "6'10"" (208 cm)", "6'11"" (211 cm)", "7'0"" (213 cm)", "7'1"" (216 cm)", "7'2"" (218 cm)", "7'3"" (221 cm)", "7'4"" (224 cm)", "7'5"" (226 cm)", "7'6"" (229 cm)", "7'7"" (231 cm)", "7'8"" (234 cm)", "7'9"" (236 cm)", "7'10"" (239 cm)"})
        Me.HEIGHT_CB.Location = New System.Drawing.Point(115, 497)
        Me.HEIGHT_CB.Name = "HEIGHT_CB"
        Me.HEIGHT_CB.Size = New System.Drawing.Size(171, 24)
        Me.HEIGHT_CB.TabIndex = 35
        '
        'WEIGHT_CB
        '
        Me.WEIGHT_CB.FormattingEnabled = True
        Me.WEIGHT_CB.Items.AddRange(New Object() {"50 Kg (110.2312 lbs)", "51 Kg (112.4354 lbs)", "52 Kg (114.6396 lbs)", "53 Kg (116.8438 lbs)", "54 Kg (119.048 lbs)", "55 Kg (121.2543 lbs)", "56 Kg (123.4585 lbs)", "57 Kg (125.6627 lbs)", "58 Kg (127.8669 lbs)", "59 Kg (130.0711 lbs)", "60 Kg (132.2774 lbs)", "61 Kg (134.4816 lbs)", "62 Kg (136.6858 lbs)", "63 Kg (138.890 lbs)", "64 Kg (141.0942 lbs)", "65 Kg (143.3006 lbs)", "66 Kg (145.5048 lbs)", "67 Kg (147.709 lbs)", "68 Kg (149.9132 lbs)", "69 Kg (152.1174 lbs)", "70 Kg (154.3237 lbs)", "71 Kg (156.5279 lbs)", "72 Kg (158.7321 lbs)", "73 Kg (160.9363 lbs)", "74 Kg (163.1405 lbs)", "75 Kg (165.3468 lbs)", "76 Kg (167.551 lbs)", "77 Kg (169.7552 lbs)", "78 Kg (171.9594 lbs)", "79 Kg (174.1636 lbs)", "80 Kg (176.3699 lbs)", "81 Kg (178.5741 lbs)", "82 Kg (180.7783 lbs)", "83 Kg (182.9825 lbs)", "84 Kg (185.1867 lbs)", "85 Kg (187.393 lbs)", "86 Kg (189.5972 lbs)", "87 Kg (191.8014 lbs)", "88 Kg (194.0056 lbs)", "89 Kg (196.2098 lbs)", "90 Kg (198.4162 lbs)", "91 Kg (200.6204 lbs)", "92 Kg (202.8246 lbs)", "93 Kg (205.0288 lbs)", "94 Kg (207.233 lbs)", "95 Kg (209.4393 lbs)", "96 Kg (211.6435 lbs)", "97 Kg (213.8477 lbs)", "98 Kg (216.0519 lbs)", "99 Kg (218.2561 lbs)", "100 Kg (220.4624 lbs)"})
        Me.WEIGHT_CB.Location = New System.Drawing.Point(115, 529)
        Me.WEIGHT_CB.Name = "WEIGHT_CB"
        Me.WEIGHT_CB.Size = New System.Drawing.Size(171, 24)
        Me.WEIGHT_CB.TabIndex = 36
        '
        'NATIONALITY_CB
        '
        Me.NATIONALITY_CB.FormattingEnabled = True
        Me.NATIONALITY_CB.Items.AddRange(New Object() {"American", "Canadian", "Australian", "French", "Spanish", "German", "Greek", "Serbian", "Croatian", "Slovenian", "Nigerian", "Cameroonian", "Congolese", "Angolan", "Brazilian", "Argentinian", "Chinese", "Japanese", "South Korean", "Filipino", "Lithuanian", "Latvian", "Swedish", "Turkish", "British", "Dutch", "Danish", "Finnish", "Russian", "Ukrainian", "Israeli", "Italian", "Senegalese", "Malian", "Montenegrin", "Swiss", "Austrian", "Belgian", "Jamaican", "Puerto Rican", "Venezuelan", "Mexican", "Dominican", "Bahamian", "Georgian", "Haitian", "Mozambican", "New Zealander", "Polish", "Portuguese"})
        Me.NATIONALITY_CB.Location = New System.Drawing.Point(516, 335)
        Me.NATIONALITY_CB.Name = "NATIONALITY_CB"
        Me.NATIONALITY_CB.Size = New System.Drawing.Size(121, 24)
        Me.NATIONALITY_CB.TabIndex = 37
        '
        'POSITION_CB
        '
        Me.POSITION_CB.FormattingEnabled = True
        Me.POSITION_CB.Items.AddRange(New Object() {"Point Guard (PG)", "Shooting Guard (SG)", "Small Forward (SF)", "Power Forward (PF)", "Center (C)"})
        Me.POSITION_CB.Location = New System.Drawing.Point(516, 372)
        Me.POSITION_CB.Name = "POSITION_CB"
        Me.POSITION_CB.Size = New System.Drawing.Size(121, 24)
        Me.POSITION_CB.TabIndex = 38
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.Label8.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.27826!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label8.ForeColor = System.Drawing.SystemColors.Menu
        Me.Label8.Location = New System.Drawing.Point(13, 32)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(331, 30)
        Me.Label8.TabIndex = 48
        Me.Label8.Text = "PLAYER REGISTRATION"
        '
        'Form_CRUD_Player
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(682, 731)
        Me.Controls.Add(Me.Label8)
        Me.Controls.Add(Me.POSITION_CB)
        Me.Controls.Add(Me.NATIONALITY_CB)
        Me.Controls.Add(Me.WEIGHT_CB)
        Me.Controls.Add(Me.HEIGHT_CB)
        Me.Controls.Add(Me.DateTimePicker_DATEOFBIRTH)
        Me.Controls.Add(Me.SEARCH_BTTN)
        Me.Controls.Add(Me.DELETE_BTTN)
        Me.Controls.Add(Me.UPDATE_BTTN)
        Me.Controls.Add(Me.CREATE_BTTN)
        Me.Controls.Add(Me.NEW_BTTN)
        Me.Controls.Add(Me.JERSEYNUMBER_TB)
        Me.Controls.Add(Me.Label9)
        Me.Controls.Add(Me.Label11)
        Me.Controls.Add(Me.Label12)
        Me.Controls.Add(Me.LASTNAME_TB)
        Me.Controls.Add(Me.FIRSTNAME_TB)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.PLAYERID_TB)
        Me.Controls.Add(Me.DataGridView1)
        Me.Controls.Add(Me.Button1)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.Margin = New System.Windows.Forms.Padding(4)
        Me.Name = "Form_CRUD_Player"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Form_CRUD_Player"
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents Button1 As Button
    Friend WithEvents DataGridView1 As DataGridView
    Friend WithEvents PLAYERID_TB As TextBox
    Friend WithEvents Label1 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents Label5 As Label
    Friend WithEvents Label6 As Label
    Friend WithEvents FIRSTNAME_TB As TextBox
    Friend WithEvents LASTNAME_TB As TextBox
    Friend WithEvents JERSEYNUMBER_TB As TextBox
    Friend WithEvents Label9 As Label
    Friend WithEvents Label11 As Label
    Friend WithEvents Label12 As Label
    Friend WithEvents NEW_BTTN As Button
    Friend WithEvents CREATE_BTTN As Button
    Friend WithEvents UPDATE_BTTN As Button
    Friend WithEvents DELETE_BTTN As Button
    Friend WithEvents SEARCH_BTTN As Button
    Friend WithEvents DateTimePicker_DATEOFBIRTH As DateTimePicker
    Friend WithEvents HEIGHT_CB As ComboBox
    Friend WithEvents WEIGHT_CB As ComboBox
    Friend WithEvents NATIONALITY_CB As ComboBox
    Friend WithEvents POSITION_CB As ComboBox
    Friend WithEvents Label8 As Label
End Class
